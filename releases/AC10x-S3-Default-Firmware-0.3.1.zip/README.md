# AC10x ESP32-S3 默认固件 0.3.1

**By mondraker**

48 kHz USB 声卡，支持 AC101S 模拟／数字麦克风、人声清晰播放和 AEC 免提通话。

- [GPIO 接线与应用更新](firmware/s3/README.md)
- [数字麦克风接线与使用](DMIC.md)
- [AEC 设置](AEC.md)
- [源码与构建方法](firmware/s3/source/README.md)
- [完整上位机](https://github.com/HwzLoveDz/ac10x-audio-lab)
- [CC BY-NC-SA 4.0](LICENSE) · [第三方组件](THIRD-PARTY-NOTICES.md)

固件启动默认使用模拟麦克风；数字输入在完整上位机的 Quick Start 中选择。0.3.0 和 0.2.1 回退镜像随包保留。
