const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const E=require('../examples.js'),C=require('../codec.js'),T=require('../transport.js'),{FakeHID,config}=require('./fake-hid.cjs'),{make}=require('./verify-properties.cjs');
let n=0;const pass=s=>{console.log('PASS '+s);n++;};
async function fixture(kind,modern,fn){const device=new FakeHID({bytes:10});device.vendorId=0x303a;device.productId=kind==='S3'?0x4005:0x4004;device.aecFirmware=modern;Object.assign(device.mem,{12:0x73,13:0});const x=make({device}),H=x.w.AudioHardwareUI;try{await x.flush();await H.connect();await x.flush();await fn(x,H,device);x.invariant();assert.ok(device.maxActive<=1);}finally{x.close();}}
(async()=>{
const baseline=JSON.parse(fs.readFileSync(path.join(__dirname,'aec-baseline.json')));
for(const name of ['firmware/source/main/codec_default_profile.h','firmware/source/main/audio_pipe.c','firmware/source/main/usb_owner.c','firmware/source/main/stream_fade.h']){const key=name;assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname,'..',name))).digest('hex'),baseline[key]);}
assert.deepEqual(E.quickExample('default',config()),E.defaultFirmware(config()));pass('default codec masks, raw FIFO, playback ownership and fades remain byte-identical');
const a=E.quickExample('aec-call',config(),{fixedAudio:true});assert.equal(a.clock.fs,48000);assert.deepEqual(a.routing.txL,{rec:false,play:true,recHalf:false,playHalf:false});assert.deepEqual(a.routing.txR,{rec:true,rx:false,recHalf:false,rxHalf:false});assert.equal(a.agc.enabled,false);assert.equal(a.routing.dac.rec,false);pass('AEC uses synchronized post-EQ PLAY left / MIC right, 48 kHz USB, no monitor or AGC');
for(const kind of ['TI','S31']){const d={vendorId:kind==='TI'?0x0451:0x303a,productId:kind==='TI'?0x4822:0x4004};assert.equal(T.adapterProfile(d).kind,kind);}
await fixture('S31',false,async(x,H,d)=>{const writes=d.writes;assert.equal(x.$('[data-quick-apply="aec-call"]').disabled,true);await H.quickStart('aec-call');assert.equal(H.getState().quickStart.phase,'error');assert.equal(d.writes,writes);assert.ok(d.sent.every(q=>q.command<0x7c||q.command===0x7e));});pass('Legacy S31 AEC card and programmatic writes are blocked without extension traffic');
await fixture('S3',false,async(x,H,d)=>{const before={...d.mem};await H.quickStart('aec-call');assert.equal(H.getState().quickStart.phase,'error');assert.match(H.getState().failure,/AEC/);assert.deepEqual(d.mem,before);assert.equal(H.getState().connected,true);assert.equal(d.writes,0);});pass('old S3 firmware reports unsupported before codec writes and stays connected');
await fixture('S3',true,async(x,H,d)=>{
 await H.quickStart('aec-call');assert.equal(H.getState().quickStart.phase,'verified',H.getState().failure);assert.equal(H.getState().quickStart.aec.enabled,true);assert.equal(d.mem[0x13],6);assert.equal(d.aecEnabled,true);assert.equal(d.sent.filter(q=>q.command===0x7c).at(-1).payload[2],1);
 for(const lang of ['en','zh-CN']){x.w.AudioI18n.setLanguage(lang);x.$('#quickStart').click();await x.flush();if(lang==='en')assert.doesNotMatch(x.$('#quickStartPicker').textContent,/[\u3400-\u9fff]/);x.$('#closeQuickStart').click();}
 await H.quickStart('default');assert.equal(H.getState().quickStart.phase,'verified');assert.equal(d.aecEnabled,false);assert.equal(d.mem[0x13],5);const writes=d.writes;await H.quickStart('default');assert.equal(d.writes,writes);
});pass('one-click AEC activates after verified codec routing; bilingual chooser and default raw restoration work');
await fixture('S3',true,async(x,H,d)=>{
 await H.quickStart('default');const before={...d.mem};d.hook=({command,value})=>command===0x7c&&value===0?{}:{};
 let rejected=false;d.hook=({command})=>command===0x7c&&d.aecEnabled===false&&!rejected?{mutate:(_d,p)=>{if(p[4]===1){rejected=true;p[8]=0;}}}:{};
 await H.quickStart('aec-call');assert.equal(rejected,true);assert.equal(H.getState().quickStart.phase,'error');assert.equal(d.aecEnabled,false);for(const [k,v]of Object.entries(before))assert.equal(d.mem[k],v,'restore '+k);
});pass('AEC allocation rejection cannot report success and restores the previous codec configuration');
await fixture('S3',true,async(x,H,d)=>{await H.quickStart('default');const before={...d.mem};let cancelled=false;d.hook=({command})=>command===0x7c?{mutate:(_d,p)=>{if(p[4]===1&&!cancelled){cancelled=true;H.cancel();}}}:{};await H.quickStart('aec-call');assert.equal(cancelled,true);assert.notEqual(H.getState().quickStart.phase,'verified');assert.equal(d.aecEnabled,false);for(const [k,v]of Object.entries(before))assert.equal(d.mem[k],v);});pass('cancelling during AEC mode acknowledgement disables processing and restores previous routing');
assert.throws(()=>T.decode(Uint8Array.from([0x7c,0,0,0,0,0,0,0,0,0]),{command:0x7c,value:1}),/not supported/);assert.throws(()=>T.decode(Uint8Array.from([0x7d,0xae,2,1,1,0,0,0,1,0]),{command:0x7d}),/Invalid AEC/);assert.throws(()=>T.decode(Uint8Array.from([0x7c,0xae,1,1,0,0,0,0,1,0]),{command:0x7c,value:1}),/differs/);pass('malformed extension versions and mismatched mode acknowledgements are rejected');
await fixture('S31',false,async(x,H,d)=>{
 d.dmicFirmware=true;
 x.$('#hwQueryBridge').click();await x.wait(()=>!H.getState().busy);
 assert.equal(x.w.AudioHardwareTransport.deviceCapabilities(d).dmic48,true);
 assert.equal(x.w.AudioHardwareTransport.deviceCapabilities(d).aec,false);
 x.$('#quickStart').click();x.$('#quickStartMic').value='dmic';x.event(x.$('#quickStartMic'),'change');
 assert.equal(x.$('[data-quick-apply="aec-call"]').disabled,true);
 assert.equal(x.$('[data-quick-apply="default"]').disabled,false);
 await H.quickStart('aec-call');assert.equal(d.writes,0);
 await H.quickStart('default');assert.equal(H.getState().quickStart.phase,'verified');
 assert.ok(d.sent.every(r=>![0x7c,0x7d].includes(r.command)));
});pass('a bridge without PSRAM AEC capability retains DMIC and never attempts AEC writes');
console.log(n+' AEC regression groups; fake HID only; no real device writes');
})().catch(e=>{console.error(e);process.exitCode=1;});
