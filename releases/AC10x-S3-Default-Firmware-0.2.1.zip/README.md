# AC10x ESP32-S3 默认固件 0.2.1

**By mondraker**

USB 声卡、人声清晰 EQ、独立麦克风录音。48 kHz / S16LE，原生 USB Full Speed。

- [GPIO 接线与应用更新](firmware/s3/README.md)
- [完整源码与构建命令](firmware/s3/source/README.md)
- [CC BY-NC-SA 4.0](LICENSE) · [第三方组件](THIRD-PARTY-NOTICES.md)

源码中的 JavaScript 测试依赖可在本目录运行 `npm ci` 安装；固件构建使用 ESP-IDF。
