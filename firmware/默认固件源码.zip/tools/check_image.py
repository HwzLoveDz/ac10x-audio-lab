"""Check descriptors and callback binding in the actual linked ESP32-S31 ELF."""
from pathlib import Path
from elftools.elf.elffile import ELFFile
import hashlib
import json

root = Path(__file__).resolve().parents[1]
with (root / 'build/ac10x_s31_bridge.elf').open('rb') as f:
    elf = ELFFile(f)
    assert elf['e_machine'] == 'EM_RISCV'
    syms = elf.get_section_by_name('.symtab')
    def data(name):
        s = syms.get_symbol_by_name(name)[0]
        sec = elf.get_section(s['st_shndx'])
        start = s['st_value'] - sec['sh_addr']
        return sec.data()[start:start+s['st_size']]
    def u16(b, n): return int.from_bytes(b[n:n+2], 'little')
    device = data('device_descriptor')
    assert len(device) == 18 and u16(device, 2) == 0x0200
    assert u16(device, 8) == 0x303a and u16(device, 10) == 0x4004
    assert u16(device, 12) == 0x0302
    for name, packet, hz, interval in [('config_hs',28,8000,1), ('config_fs',196,1000,1)]:
        b = data(name)
        assert u16(b,2) == len(b) and b[4] == 4
        descriptors=[]; p=0
        while p < len(b):
            n=b[p]; assert n>=2 and p+n<=len(b)
            descriptors.append(b[p:p+n]); p+=n
        interfaces = [d for d in descriptors if d[1] == 4]
        assert [(d[2],d[3],d[4]) for d in interfaces] == [(0,0,0),(1,0,0),(1,1,2),(2,0,0),(2,1,1),(3,0,2)]
        eps={d[2]:d for d in descriptors if d[1] == 5}
        assert set(eps)=={0x01,0x82,0x83,0x04,0x84}
        for ep in (0x01,0x83):
            assert u16(eps[ep],4)==packet and eps[ep][6]==interval
            assert packet>=((48000//hz)+1)*4
            assert eps[ep][3] == 5
        assert eps[0x82][3] == 0x11 and u16(eps[0x82],4) == 4
        assert u16(eps[0x84],4)==10 and u16(eps[0x04],4)==10
        iad=next(d for d in descriptors if d[1]==11)
        assert iad[2:4] == bytes([0,3])
        clocks=[d for d in descriptors if d[1]==0x24 and d[2]==0x0a]
        assert len(clocks)==1 and clocks[0][3:6]==bytes([4,1,5])
        # Every data format is stereo 16-bit PCM and tied to the common clock.
        formats=[d for d in descriptors if d[1]==0x24 and d[2]==2 and len(d)==6]
        assert len(formats)==2 and all(d[3:]==bytes([1,2,16]) for d in formats)
        general=[d for d in descriptors if d[1]==0x24 and d[2]==1 and len(d)==16]
        assert len(general)==2 and all(d[10]==2 for d in general)
        ac = next(d for d in descriptors if d[1]==0x24 and d[2]==1 and len(d)==9)
        assert u16(ac,6)==75
    assert not syms.get_symbol_by_name('pattern'), 'Synthetic probe must not be linked into real audio'
    for required in ('i2s_channel_enable','i2s_channel_write','i2s_channel_read'):
        assert syms.get_symbol_by_name(required), ('Real I2S path missing',required)
    for packet_buffer in ('lin_buf_in','lin_buf_out'):
        assert len(data(packet_buffer)) >= 196, ('Linear packet buffer absent',packet_buffer)
    for hot_symbol in ('dcd_int_handler','audiod_xfer_isr','audio_pipe_playback','audio_pipe_capture','tu_hwfifo_read','usbd_edpt_xfer'):
        address = syms.get_symbol_by_name(hot_symbol)[0]['st_value']
        assert 0x2f000000 <= address < 0x30000000, ('USB path still in flash',hot_symbol,hex(address))
    report=data('hid_report')
    assert bytes([0x95,10]) in report and 0x85 not in report  # no report ID
    for name in ['tud_descriptor_device_cb','tud_descriptor_configuration_cb',
                 'tud_audio_get_req_entity_cb','tud_audio_set_itf_cb',
                 'tud_audio_feedback_params_cb','tud_hid_set_report_cb',
                 'tud_event_hook_cb','bridge_usb_task_step','audio_pipe_usb_sync',
                 'audio_pipe_usb_pump']:
        s=syms.get_symbol_by_name(name)[0]
        assert s['st_info']['bind']=='STB_GLOBAL', (name,'weak fallback selected')
blob=(root/'build/ac10x_s31_bridge.bin').read_bytes()
assert len(blob)<0x800000
result={'target':'esp32s31','bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),
        'usb':'UAC2 duplex S16LE stereo 48000 + HID10, FS/HS',
        'descriptors':'passed','strong_callbacks':'passed','source':'external codec I2S; only explicit startup preroll zeros','physical_test':'not run'}
print(json.dumps(result,ensure_ascii=False,indent=2))

