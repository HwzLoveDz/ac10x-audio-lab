#pragma once
// ESP32-S31-Korvo-1 V1.1, J14 LCD connector. LCD must be unplugged.
// These seven RGB data lines do not touch board audio, UART, strapping or CAN.
#define BRIDGE_MCLK_GPIO 8  // J14.13 / LCD_B3
#define BRIDGE_BCLK_GPIO 9  // J14.16 / LCD_B4
#define BRIDGE_LRCK_GPIO 10 // J14.15 / LCD_B5
#define BRIDGE_DOUT_GPIO 11 // J14.18 / LCD_B6: S31 -> AC101S SDIN
#define BRIDGE_DIN_GPIO 12  // J14.17 / LCD_B7: AC101S SDOUT -> S31
#define BRIDGE_SDA_GPIO 13  // J14.20 / LCD_G2
#define BRIDGE_SCL_GPIO 14  // J14.19 / LCD_G3
#define BRIDGE_SAMPLE_RATE 48000
#define BRIDGE_FRAME_BYTES 4 // USB PCM: 2 channels x signed 16-bit LE
#define BRIDGE_USB_VID 0x303A
#define BRIDGE_USB_PID 0x4004 // Local development identity, not a production VID/PID allocation.
