# 默认固件 0.3.3

ESP32-S31，沿用已验证的ESP-IDF 6.2.0 preview及S31工具链。按idf.py标准构建；保留定制TinyUSB组件及许可证。main/codec_default_profile.h由上位机qa/export-default-firmware.cjs生成，Quick Start与启动默认参数同源。仅应用区镜像，不含SDK、编译器、录音或账号资料。
