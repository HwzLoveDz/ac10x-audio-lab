# S31 default firmware 0.3.3

Build with the ESP-IDF target and component revisions selected by sdkconfig and dependencies.lock. Run idf.py build in the configured SDK environment.

Original project code uses LICENSE.project; third-party components retain their licenses.
